<?php

namespace TinyC\NodeQ;

class Relation extends CoreRelation {
    
}
