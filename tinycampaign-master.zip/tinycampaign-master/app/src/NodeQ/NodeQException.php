<?php

namespace TinyC\NodeQ;

/**
 * Exception extend
 *
 * @category Exceptions
 * @author Grzegorz Kuźnik
 * @copyright (c) 2013, Grzegorz Kuźnik
 */
class NodeQException extends \Exception {
    
}
