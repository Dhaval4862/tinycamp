<?php

namespace TinyC\NodeQ;

class Database extends CoreDatabase {
    
}
